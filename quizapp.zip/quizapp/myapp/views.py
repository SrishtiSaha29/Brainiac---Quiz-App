from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from .models import *
from .forms import *
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.decorators import login_required
from .decorators import unauthenticated_user,allowed_users,admin_only
from django.contrib.auth.models import Group
from django.http import JsonResponse


# Create your views here.
# @login_required(login_url='login')
def Home(request):   #landing page
    players=Player.objects.all()
    # form=ContactForm
    # player=ProfileForm.objects.all
    # form=ProfileForm
    
    return render(request,'index.html')


@unauthenticated_user
def registerpage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form=CreateUserForm()
        if request.method=='POST':
            form=CreateUserForm(request.POST)
            if form.is_valid():
                user=form.save()
                username=form.cleaned_data.get('username')
                group=Group.objects.get(name='players')
                user.groups.add(group)
                Player.objects.create(user=user,name=user.username,email=user.email)
                messages.success(request,'User Successfully created for '+username)
                return redirect('registerpage')
        context={'form':form}

        return render(request,'register.html',context)

# @unauthenticated_user
def loginpage(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            if user.is_superuser:
                return redirect('dashboard_total')
            else:
                return redirect('dashboard')
        else:
            messages.info(request,"Credentials invalid !!")
            print("Username or password error")
            return redirect('login')
    
    return render(request,'login.html')

def logoutpage(request):
        logout(request)
        return redirect('/')


# --------------------AFTER LOGIN-----------------------


def dashboard(request):    #home page
    players=Player.objects.all()
    return render(request,'dashboard.html',{'players':players})

def quiz1(request):
    if request.method == 'POST':
        # no need to do this
        # request_csrf_token = request.POST.get('csrfmiddlewaretoken', '')
        request_getdata = request.POST.get('getdata', None) 
        # make sure that you serialise "request_getdata" 
        return JsonResponse(request_getdata) 
    return render(request,'quiz1.html')

def quiz2(request):
    return render(request,'quiz2.html')

def quiz3(request):
    return render(request,'quiz3.html')

def quiz4(request):
    return render(request,'quiz4.html')

def quiz5(request):
    return render(request,'quiz5.html')

def quiz6(request):
    return render(request,'quiz6.html')

def quiz7(request):
    return render(request,'quiz7.html')

def quiz8(request):
    return render(request,'quiz8.html')


def leaderboard(request):  #top 4 ranks with profile_pic name and bio
    players = Player.objects.all()
    # players_count=players.count()
    context={'players':players}
    return render(request,'leaderboard.html',context)

#-----------------for ref----------------
# @login_required(login_url="login")
# def leaderboard_view(request):

#     user_object = User.objects.get(username=request.user)
#     user_profile = Profile.objects.get(user=user_object)

#     leaderboard_users = UserRank.objects.order_by('rank')

#     context = {"leaderboard_users": leaderboard_users, "user_profile": user_profile}
#     return render(request, "leaderboard.html", context)

   

# @login_required(login_url='login')
# @allowed_users(allowed_roles=['players'])
# def profile(request,id): #profilepage
#     players=Player.objects.get(id=id)
#     context={'players':players}
#     return render(request,'profile.html',context)

@login_required(login_url='login')
def profile(request): #editform
    player=request.user.player
    form=PlayerForm(request.POST,instance=player)
    if request.method=='POST':
        form=PlayerForm(request.POST,request.FILES,instance=player)
        if form.is_valid():
            form.save()
    context={'form':form}
    # player=ProfileForm.objects.get(id=id)
    return render(request,'profile_edit.html',context)

def confirm(request): #delete
    players=Player.objects.all()
    # players.delete()
    context={"players":players}
    return render(request,"confirm.html",context)

def contact_us(request):
    print(request)
    if request.method == 'POST':
        form=ContactForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('dashboard')
    return render(request,'contact_us.html')

def terms_conditions(request):
    return render(request,'terms_conditions.html')

def blog(request):
    return render(request,'blog.html')

def about(request):
    return render(request,'about.html')

@login_required(login_url='login')
@admin_only
def dashboard_total(request):
    players = Player.objects.all()
    players_count=players.count()
    quizzes=Quiz.objects.all()
    total_quizzes=quizzes.count()
    # questions = Questions.objects.all().count()
    # player=request.user.player
    # form=PlayerForm(instance=player)
    form=PlayerForm()
    if request.method=='POST':
        # form=PlayerForm(request.POST,request.FILES,instance=player)
        form=PlayerForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
    context={'form':form,'players_count':players_count,'players':players,'quizzes':quizzes,'total_quizzes':total_quizzes}
    return render(request,'dashboard_total.html',context)

# def gain_percentage(total, today):
#     if total > 0 and today > 0:
#         gain = math.floor((today *100)/total)
#         return gain
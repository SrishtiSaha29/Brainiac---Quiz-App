from django.contrib import admin
from .models import *
# from .models import quiz_contact

# Register your models here.


admin.site.register(ContactUs)
admin.site.register(Player)
admin.site.register(Quiz)
